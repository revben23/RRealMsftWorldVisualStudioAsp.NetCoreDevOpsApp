﻿namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp
{
    public interface IGreeter
    {
    }
}