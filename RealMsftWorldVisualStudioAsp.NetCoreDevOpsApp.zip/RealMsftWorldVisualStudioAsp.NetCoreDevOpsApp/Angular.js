﻿(function () {
    'use strict';

    angular.module('Angular', [
        // Angular modules 
        'ngRoute'

        // Custom modules 

        // 3rd Party Modules

    ]);
})();

