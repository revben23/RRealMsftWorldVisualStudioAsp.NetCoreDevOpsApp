﻿namespace RealMsftWorldVisualStudioAsp.Services
{
    internal class ContactsInformationDbContext
    {
    }
}