﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    public class ContactMessage : ContactMessageDisplay
    {
        public string ContactMessageDisplay { get; set; }
    }
}
