﻿namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    public class ContactMessageDisplay
    {
    }
}