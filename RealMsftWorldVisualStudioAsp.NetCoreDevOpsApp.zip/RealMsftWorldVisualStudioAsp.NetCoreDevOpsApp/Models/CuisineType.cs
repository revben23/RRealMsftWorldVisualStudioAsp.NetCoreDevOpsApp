﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    public enum CuisineType
    {
        None,
        Jamaican,
        Trinidadian,
        American,
        French,
        Italian

    }
}
