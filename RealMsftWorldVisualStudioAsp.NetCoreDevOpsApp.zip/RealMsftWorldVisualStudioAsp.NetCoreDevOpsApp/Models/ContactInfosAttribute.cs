﻿using System;

namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    internal class ContactInfosAttribute : Attribute
    {
    }
}