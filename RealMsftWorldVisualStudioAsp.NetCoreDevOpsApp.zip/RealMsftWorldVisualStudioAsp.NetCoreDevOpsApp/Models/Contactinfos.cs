﻿namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    public class Contactinfos
    {
    }
}