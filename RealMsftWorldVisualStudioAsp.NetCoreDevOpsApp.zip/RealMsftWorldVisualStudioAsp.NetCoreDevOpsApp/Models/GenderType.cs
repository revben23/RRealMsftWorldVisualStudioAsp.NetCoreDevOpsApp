﻿namespace RealMsftWorldVisualStudioAsp.NetCoreDevOpsApp.Models
{
    public enum GenderType
    {
        Male,
        Female,
        Other
        
    }
}