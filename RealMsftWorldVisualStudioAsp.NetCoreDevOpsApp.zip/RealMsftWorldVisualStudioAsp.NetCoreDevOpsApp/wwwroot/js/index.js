﻿




//alert("Hello Microsoft World");
//console.log("Hello Microsoft World");

//ar form = document.getElementById("theForm");
//form.hidden = false;


//var submit = document.getElementById("submit");
//submit.addEventListener("click", function () {
 //  alert("Submititng Message");

//});

var label = document.getElementById("labelFirst")
label.addEventListener("click", function () {
    alert("You Clicked Me");

});
